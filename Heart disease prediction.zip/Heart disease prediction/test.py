import numpy as np
import pandas as pd
from keras.models import model_from_json
from sklearn.preprocessing import LabelEncoder

dataset = pd.read_csv('Heart_Disease_Prediction.csv')
x = dataset.iloc[:, 0:13].values
y = dataset.iloc[:, 13].values

# Ensure input data is of the correct type
x = x.astype(float)

# Encode categorical output labels to numeric
label_encoder = LabelEncoder()
y = label_encoder.fit_transform(y)

json_file = open('model.json', 'r')
loaded_model_json = json_file.read()
json_file.close()
model = model_from_json(loaded_model_json)
model.load_weights("model.h5")
print("Loaded model from disk")

predictions = model.predict(x)
for i in range(31,60):
	print('%s => %d (expected %d)' % (x[i].tolist(), predictions[i], y[i]))
