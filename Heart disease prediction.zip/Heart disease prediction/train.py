

import numpy as np
import pandas as pd
from keras.models import Sequential
from keras.layers import Dense
from sklearn.preprocessing import StandardScaler
from sklearn.utils.class_weight import compute_class_weight

# Load dataset using pandas for better handling of CSV
dataset = pd.read_csv('Heart_Disease_Prediction.csv')

# Assuming the last column is the target variable
x = dataset.iloc[:, 0:13].values  # Input features
y = dataset.iloc[:, 13].values    # Output labels

# Ensure input data is of the correct type
x = x.astype(float)

# Manually encode 'Presence' to 0 and 'Absence' to 1
y = pd.Series(y).replace({'Presence': 0, 'Absence': 1}).values

# Normalize input data
scaler = StandardScaler()
x = scaler.fit_transform(x)

print("Input after scaling", x)
print("Encoded Output", y)

# Check class distribution
print("Class distribution:", pd.Series(y).value_counts())

# Compute class weights
class_weights = compute_class_weight('balanced', classes=np.unique(y), y=y)
class_weights = dict(enumerate(class_weights))

# Model layers
model = Sequential()
model.add(Dense(12, input_dim=13, activation='relu'))
model.add(Dense(8, activation='relu'))
model.add(Dense(4, activation='relu'))
model.add(Dense(1, activation='sigmoid'))

model.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy'])

# Model Training
model.fit(x, y, epochs=70, batch_size=10, class_weight=class_weights)

# Evaluation
_, accuracy = model.evaluate(x, y)
print('Accuracy: %.2f' % (accuracy * 100))

# Model Save
model_json = model.to_json()
with open("model.json", "w") as json_file:
    json_file.write(model_json)
model.save("model.h5")
print("Saved model to disk")

